package com.itmuch.cloud;

public @interface ExcludeFromComponentScan {

}
