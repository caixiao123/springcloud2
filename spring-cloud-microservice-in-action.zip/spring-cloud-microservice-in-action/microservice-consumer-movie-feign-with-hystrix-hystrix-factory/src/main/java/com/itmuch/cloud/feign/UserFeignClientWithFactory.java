package com.itmuch.cloud.feign;

public interface UserFeignClientWithFactory extends UserFeignClient {

}
